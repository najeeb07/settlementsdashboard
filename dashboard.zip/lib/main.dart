import 'package:flutter/material.dart';
import 'package:flutter/services.dart';  // For loading assets
import 'dart:typed_data';  // For reading binary data from the Excel file
import 'dart:io';  // For writing files
import 'package:excel/excel.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'dart:html' as html;
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:collection/collection.dart';
import 'package:pdf/widgets.dart' as pdfWidgets;

void main() {
  runApp(const RestaurantReportApp());
}

class RestaurantReportApp extends StatelessWidget {
  const RestaurantReportApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant Report Generator',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ReportGeneratorPage(),
    );
  }
}

class ReportGeneratorPage extends StatefulWidget {
  const ReportGeneratorPage({Key? key}) : super(key: key);

  @override
  _ReportGeneratorPageState createState() => _ReportGeneratorPageState();
}

class _ReportGeneratorPageState extends State<ReportGeneratorPage> {
  final TextEditingController restaurantIdController = TextEditingController();

  // Load Excel data from assets
  Future<List<Map<String, dynamic>>> readExcelData() async {
    final ByteData data = await rootBundle.load('file/orders.xlsx');
    final Uint8List bytes = data.buffer.asUint8List();
    final excel = Excel.decodeBytes(bytes);

    final sheet = excel!.tables['Orders'];
    final dataList = <Map<String, dynamic>>[];

    if (sheet != null) {
      for (var row in sheet.rows.skip(1)) { // Skip the header row
        dataList.add({
          'Restaurant ID': row[2]?.value.toString(),
          'Order Date': row[4]?.value.toString(),
          'Total Amount': row[3]?.value,
          'Items': row[5]?.value.toString(),
          'Delivery': row[11]?.value,
          'New Customer': row[9]?.value.toString().toLowerCase() == 'true', // Assuming new customer info is in column 10
          'Dine In': row[12]?.value.toString().toLowerCase() == 'dine in', // Example: Assuming dine-in info is in column 13. Adapt as needed.
          'Customer Name': row[9]?.value.toString() ?? '', // Provide default empty string if null
          'Customer Phone': row[10]?.value.toString() ?? '',  // Also handle null for Customer Phone
          'Restaurant Name': row[12]?.value.toString() ?? '', // Assuming Restaurant name is at index 13 in the Excel

          // ... Add other fields you need from the Excel (Take Away, Delivery, etc.)
        });
      }
    } else {
      print('Error: Sheet "Orders" not found.');
      throw Exception('Sheet "Orders" not found in the Excel file.');
    }
    return dataList;
  }




  Future<void> generatePdfReport(
      String restaurantId, List<Map<String, dynamic>> data) async {
    final pdf = pw.Document();
    final font = await pdfWidgets.Font.ttf(await rootBundle.load('fonts/noto.ttf'));

    final filteredData = data
        .where((row) => row['Restaurant ID'] == restaurantId)
        .toList();
    final totalCustomers = filteredData.length; // Assuming each row represents a customer order.

    // Group orders by customer phone to count repeat customers:
    final ordersByCustomer = groupBy<Map<String, dynamic>, String>(
        filteredData, (order) => order['Customer Phone'] ?? '');

    final repeatCustomers = ordersByCustomer.entries
        .where((entry) => entry.value.length > 1)
        .length;

    final totalRevenue = filteredData.fold<double>(0, (sum, row) => sum + (row['Total Amount'] is num ? row['Total Amount'].toDouble() : 0));
    final totalOrders = filteredData.length;
    final totalItemsSold = filteredData.fold<int>(0, (sum, row) => sum + (row['Items']?.toString().split(',').length ?? 0));

    final newCustomers = filteredData.where((row) => row['New Customer'] == true).length;
    final deliveryOrders = filteredData.where((row) => row['Delivery'] != null && row['Delivery'] != 0).length; // Assuming a non-zero Delivery value indicates a delivery order
    final restaurantName = data.firstWhereOrNull((row) => row['Restaurant ID'] == restaurantId)?['Restaurant Name'] ?? '';


    final dateFormat = DateFormat('MMMM'); // Full month name
    final monthlyRevenue = <String, double>{};
    for (final order in filteredData) {
      final orderDate = DateTime.tryParse(order['Order Date'] ?? '');
      if (orderDate != null) {
        final monthName = dateFormat.format(orderDate);
        monthlyRevenue[monthName] = (monthlyRevenue[monthName] ?? 0) + (order['Total Amount'] is num ? order['Total Amount'].toDouble() : 0);
      }
    }

    // Sort monthly revenue alphabetically:
    final sortedMonthlyRevenue = Map.fromEntries(
        monthlyRevenue.entries.toList()..sort((a, b) => a.key.compareTo(b.key)));
    // Customer-specific data preparation:



    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start, // Align text to the left
          children: [
            pw.Text('Restaurant Report', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
            pw.Text('Restaurant Name: $restaurantName', style: pw.TextStyle(fontSize: 16)),
            pw.Text('Restaurant ID: $restaurantId', style: pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 10),


            pw.Text(
              'Total Revenue: ₹${totalRevenue.toStringAsFixed(2)}',
              style: pw.TextStyle(font: font, fontSize: 20),
            ),

            pw.Text('Total Orders: $totalOrders'),
            pw.Text('Total Items Sold: $totalItemsSold'),
            pw.Text('Total Customers: $totalCustomers'), // Replace 'New Customers' with 'Total Customers'
            pw.Text('Repeat Customers: $repeatCustomers'),

            pw.Text('Delivery Orders: ${((deliveryOrders / totalOrders) * 100).toStringAsFixed(0)}% ($deliveryOrders out of $totalOrders orders)'), // Improved delivery percentage display

            pw.SizedBox(height: 10), // Add some spacing

            pw.Text('Monthly Revenue:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            for (final entry in sortedMonthlyRevenue.entries) // Display sorted revenue
              pw.Text('${entry.key}: ₹${entry.value.toStringAsFixed(2)}',style: pw.TextStyle(font: font, fontSize: 20)),

            // ... If you need to add a "No data for other months" message, you can conditionally add it here
            if (sortedMonthlyRevenue.length <=2)
              for (final month in ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November','December'])
                if(!sortedMonthlyRevenue.containsKey(month))
                  pw.Text('$month: ₹0.00',style: pw.TextStyle(font: font, fontSize: 20))




          ],
        ),
      ),
    );

    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('Customer List', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 10),

            pw.Table(
              border: pw.TableBorder.all(),
              columnWidths: {
                0: const pw.FlexColumnWidth(1),
                1: const pw.FlexColumnWidth(1),
                2: const pw.FlexColumnWidth(1),
              },
              children: [
                pw.TableRow(
                  children: [
                    pw.Text('Customer Name', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text('Phone Number', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text('Number of Orders', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  ],
                ),

                for (final customerEntry in ordersByCustomer.entries) ...[    // Corrected loop here
                  pw.TableRow(
                    children: [
                      pw.Text(customerEntry.value.first['Customer Name']?.toString() ?? ''), // Add null check and default value here as well
                      pw.Text(customerEntry.key),
                      pw.Text(customerEntry.value.length.toString()),
                    ],
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );


    final pdfBytes = await pdf.save();

    // Web-specific download:
    final blob = html.Blob([Uint8List.fromList(pdfBytes)]);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..download = '$restaurantId-report.pdf';
    anchor.click();
    html.Url.revokeObjectUrl(url);
  }

  // Trigger the download of the PDF file
  void triggerDownload(File pdfFile) {
    final pdfBytes = pdfFile.readAsBytesSync();
    final blob = html.Blob([Uint8List.fromList(pdfBytes)]);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..download = pdfFile.path.split('/').last;
    anchor.click();
    html.Url.revokeObjectUrl(url);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Restaurant Report Generator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 50),
            TextField(
              controller: restaurantIdController,
              decoration: const InputDecoration(
                labelText: 'Enter Restaurant ID',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final restaurantId = restaurantIdController.text;
                if (restaurantId.isNotEmpty) {
                  try {
                    final data = await readExcelData();


                    final filteredData = data.where((row) => row['Restaurant ID'] == restaurantId).toList();
                    if (filteredData.isEmpty) {
                      // Show an error message if the Restaurant ID is not found
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Restaurant ID not found.')));

                      return; // Stop further processing

                    }



                    await generatePdfReport(restaurantId, data); // Pass the original data, not filteredData



                  } catch (e) {
                    // Handle errors
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please enter a Restaurant ID.')));

                }
              },
              child: const Text('Generate Report'),
            ),


          ],
        ),
      ),
    );
  }
}